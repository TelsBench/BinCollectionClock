/*
MIT License

Copyright (c) [2024] [TEL at @TELsBench channel on youtube]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

#include <Arduino.h>
#include <TFT_eSPI.h>
#include "MyHelpers.h"
#include <time.h>
#include <NTPClient.h>

enum BinType { Wheelie =0, HandledBag=1, PaperBag=2, FoodBin=3  };

class BinContainer
{

private:
MyHelpers myHelpers;
uint16_t x;
uint16_t y;
uint16_t width;
uint16_t height;
uint16_t binType;
uint16_t fillColor;
String  caption;
String  dayString;
NTPClient timeClient;
uint8_t collectionFrequencyInWeeks=1;

time_t startCollectionDate;    

public: 
 BinContainer(NTPClient timeClient) : timeClient(timeClient){ this->timeClient = timeClient;};
 void Init( uint16_t x, uint16_t y,uint16_t width, uint16_t height, uint16_t binType, uint16_t color, String caption);

 time_t tmConvert_t(int YYYY, byte MM, byte DD, byte hh, byte mm, byte ss);

 bool leapyear(int year);
 time_t SetCollectionStartFrequency(time_t expectedStart_tm,uint16_t everyNWeeks, time_t  local_tm);
 void SetExplicitCollectionDate(time_t value);
 time_t GetNextValidCollectionDate(time_t expectedStart_tm,uint16_t everyNWeeks, time_t  local_tm);
 time_t GetCurrentCollectionDate();
 static time_t getThisSunday(time_t localTime_t);
 String getWeekday(time_t posixTime);
 
 void Draw(TFT_eSPI tft);
 void DrawWheelie(TFT_eSPI tft);
 void DrawHandledBag(TFT_eSPI tft);
 void DrawPaperBag(TFT_eSPI tft);
 void DrawFoodBin(TFT_eSPI tft);
 
};