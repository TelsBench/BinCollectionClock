/*
MIT License

Copyright (c) [2024] [TEL at @TELsBench channel on youtube]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

#include "BinContainer.h"
#include <time.h>
#include <TimeLib.h>
#include <NTPClient.h>

void BinContainer::Init( uint16_t x, uint16_t y,uint16_t width, uint16_t height, uint16_t binType , uint16_t color, String caption)
{
    this->x = x;
    this->y = y;
    this->binType = binType;
    this->width = width;
    this->height = height;
    this->fillColor = color;
    this->caption = caption;
    const char* weekdayNames[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
}

//Literally Returns this field
time_t BinContainer::GetCurrentCollectionDate()
{
  return this->startCollectionDate;
}

//Calculates the next valid Collectiion Date
time_t BinContainer::GetNextValidCollectionDate(time_t expectedStart_tm,uint16_t everyNWeeks, time_t  local_tm)
{
   // Sanitise any values on both expected and local times supplied   
   TimeElements expdtm;         //sptm Supplied Time Elements
   breakTime(expectedStart_tm,expdtm); //Time_t localTime supplied by caller
   expdtm.Hour=expdtm.Minute=expdtm.Second=0;//( Set the none Y/M/D elements to zero)
   expectedStart_tm=makeTime(expdtm);

   TimeElements localTime;        //Local Time Elements
   breakTime(local_tm,localTime); // The assginment
   localTime.Hour=localTime.Minute=localTime.Second=0;
   local_tm=makeTime(localTime);

   //If Collection Day Has Passsed Set to next collection Date
   if( local_tm>expectedStart_tm)    
   {
      //Set the date to the next available date  
      //Num seconds in n weeks to be added to current expected date Secs/Hr * hrs/Day * daysInWeek * weeks
       u_long  weeksIntervalInSeconds = 3600UL * 7 *  24UL *  everyNWeeks;
        TimeElements chkElement;
        while( expectedStart_tm < local_tm)
        {
            breakTime(expectedStart_tm,chkElement);
            expectedStart_tm+=weeksIntervalInSeconds;
        }
       return expectedStart_tm;
   }
   else
   { //Return the given expected date
      return makeTime(expdtm);
   }

}

String BinContainer::getWeekday(time_t posixTime) {
    const int SECONDS_IN_A_DAY = 86400;
    const int DAYS_IN_A_WEEK = 7;
    const char* weekdays[] = {"Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"};

    // January 1, 1970 was a Thursday
    const int BASE_DAY_OF_WEEK = 4; // Thursday (0=Sunday, 1=Monday, ..., 6=Saturday)
    
    // Calculate the number of days since January 1, 1970
    int daysSinceEpoch = posixTime / SECONDS_IN_A_DAY;

    // Calculate the weekday index
    int weekdayIndex = (BASE_DAY_OF_WEEK + daysSinceEpoch) % DAYS_IN_A_WEEK;

    return weekdays[weekdayIndex];
}

time_t BinContainer::getThisSunday(time_t localTime_t ) 
{
   TimeElements localTime_tm;
   breakTime(localTime_t,localTime_tm);
   localTime_tm.Hour=23;
   localTime_tm.Minute=59;
   localTime_tm.Second=59;
   localTime_t = makeTime(localTime_tm);

   // If this is sunday, then return the same date
   if( localTime_tm.Wday == 1) return localTime_t;
   int daysToSunday = 7 - localTime_tm.Wday + 1;

   // add  the days to get the next Sunday
   time_t sunday_t = localTime_t += daysToSunday * 24 * 3600; // 24 hours * 3600 seconds
TimeElements sunday_tm;  
breakTime(sunday_t,sunday_tm);
return sunday_t;
}

time_t BinContainer::SetCollectionStartFrequency(time_t expectedStart_tm,uint16_t everyNWeeks, time_t  local_tm)
{
   this->collectionFrequencyInWeeks = collectionFrequencyInWeeks;

   //If this date has passed, then work out the next StartDate based on that and the number of weeks spacing until the date contrived
   //is either today or in the future and use that.   
   time_t nextValidDate =  this->GetNextValidCollectionDate(expectedStart_tm,everyNWeeks,  local_tm);

   this->startCollectionDate=nextValidDate;  
   return nextValidDate;
}

void BinContainer::SetExplicitCollectionDate(time_t val)
{
   this->startCollectionDate = val;
}

bool BinContainer::leapyear(int year)
{
   if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
      return true;  // yep, it's a leap year
   else
      return false;
}

time_t BinContainer::tmConvert_t(int YYYY, byte MM, byte DD, byte hh, byte mm, byte ss)
{
  struct tm this_tm;
  tmElements_t tmSet;

  Serial.println("BIN START DATE : " + String(YYYY) + "," + String(MM) + "," + DD + "," + hh + "," + mm + "," + ss);

  tmSet.Year = YYYY - 1970;
  tmSet.Month = MM;
  tmSet.Day = DD;
  tmSet.Hour = hh;
  tmSet.Minute = mm;
  tmSet.Second = ss;
  time_t someEpochTime =  makeTime(tmSet); 

  return someEpochTime;
}

void BinContainer::Draw(TFT_eSPI tft)
{
   time_t timeNow_t = this->timeClient.getEpochTime();
   time_t colDate_t = this->GetCurrentCollectionDate();
   TimeElements te;
   TimeElements tNowEl;
   breakTime(timeNow_t,tNowEl);tNowEl.Hour=tNowEl.Minute=tNowEl.Second=0;
   timeNow_t = makeTime(tNowEl);

   breakTime(colDate_t,te);


   time_t sunday_t = BinContainer::getThisSunday(timeClient.getEpochTime());
 
   bool binVisible = colDate_t<=sunday_t &&  colDate_t>=timeNow_t;

   if(binVisible==false)
   {
      //Clear Bin Screen
      tft.fillRect(this->x,this->y,this->width,160-this->height,TFT_LIGHTGREY);
      return;
   } 

   timeClient.update();

   switch(this->binType)
   {
      //Select Bin To Draw
      case 0:DrawWheelie(tft);
      break;
      case 1:DrawHandledBag(tft);
      break;
      case 2:DrawPaperBag(tft);
      break;
      case 3:DrawFoodBin(tft);
      break;  

      default://No Action at this point.
      break;
   }
}

void BinContainer::DrawWheelie(TFT_eSPI tft)
{
  //Wheelie Bin
   tft.fillRect(x,y,width,height,fillColor);
   uint16_t wheelWidth = 0.15 * width;
   uint16_t wheelHeight = .25 * height;
   //Draw Left Wheel
   uint16_t wheelX1 = x-wheelWidth + -1;
   uint16_t wheelY1 = y+height-wheelHeight;
   tft.fillRect(wheelX1,wheelY1,wheelWidth,wheelHeight,TFT_BLACK);

   //Right Wheel
   wheelX1 = x+width +1;
   wheelY1 = y+height-wheelHeight;
   tft.fillRect(wheelX1,wheelY1,wheelWidth,wheelHeight,TFT_BLACK);

   //Draw Lid
   uint16_t lidY = y + 0.1 * height;
   tft.fillRect(x,lidY,width,3,TFT_DARKGREY);

   //Draw Caption
   uint16_t capX, capY;
   capX = x + ( width/2) ; capY=y+height+10;
   tft.setTextSize(2);
   tft.setTextColor(TFT_RED);
   tft.setTextFont(3);
   tft.drawCentreString(caption,capX,capY,1);

   //Draw DayName
   tft.setTextColor(TFT_BLACK);
   String dow =this->getWeekday(startCollectionDate);
   tft.drawCentreString(dow,capX,capY+20,1);

   //Draw Month/Day
   tft.setTextColor(TFT_BLACK);
   String monthAndDay =myHelpers.getMonthDayString((int)startCollectionDate);
   tft.drawCentreString(monthAndDay,capX,capY+40,1); 
}

//Future Development.
void BinContainer::DrawHandledBag(TFT_eSPI tft)
{
   //Future development
}
void BinContainer::DrawPaperBag(TFT_eSPI tft)
{
   //Future development
}
void BinContainer::DrawFoodBin(TFT_eSPI tft)
{
   //Future development
}
